/**
 * 
 */
package genericXMLProcessor.server;

/**
 * @author Abhishek Waichal
 * Interface SerDeserXML, a tag interface for serialization and deserialization 
 */
public interface SerDeserXML {

}
